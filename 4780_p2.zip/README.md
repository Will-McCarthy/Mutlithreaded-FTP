CSCI 4780 Spring 2021 Project 2
Jisoo Kim, Will McCarthy, Tyler Scalzo


Unfortunately, due to some complications, and dificulty
figuring some problems out, the project was not completed
on time, even with the 48 hour extension. We promise to
hit the deadlines on future assignments.

Note: .. does not work anymore. We were unable to
get that part working with the challenges of
directories with threading. You can only cd
to folders in the current directory.


Compiling:

Run "make all" in the directory with all the files. 

Running:
client: ./myftp [hostname/IP] [normalPort] [terminatePort]
server: ./myftpserver [nport] [tport]


This project was done in its entirety by Jisoo Kim, Will McCarthy, 
and Tyler Scalzo. We hereby state that we have not received
unauthorized help of any form.